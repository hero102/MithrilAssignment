package com.aurionpro.model;

public class Attempt {
    private int score;
    private String timestamp;

    public Attempt(int score, String timestamp) {
        this.score = score;
        this.timestamp = timestamp;
    }

    public int getScore() { return score; }
    public String getTimestamp() { return timestamp; }
}
