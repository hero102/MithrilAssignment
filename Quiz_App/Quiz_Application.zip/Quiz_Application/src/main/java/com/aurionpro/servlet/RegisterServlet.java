package com.aurionpro.servlet;

import java.io.IOException;
import com.aurionpro.util.DBUtil;
import com.aurionpro.util.HtmlLoader;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    String errorMessage = req.getParameter("error");
	    if (errorMessage == null) errorMessage = "";
	    String html = HtmlLoader.loadTemplate(getServletContext(), "register.html");
	    html = html.replace("${errorMessage}", errorMessage);
	    resp.setContentType("text/html");
	    resp.getWriter().write(html);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    String username = req.getParameter("username");
	    String password = req.getParameter("password");
	    String email = req.getParameter("email");

	    try {
	        if (DBUtil.isUsernameExists(username)) {
	            resp.sendRedirect("register?error=Username already taken, please choose another.");
	            return;
	        }
	        // Register user logic
	        boolean success = DBUtil.registerUser(username, password, email);
	        if (success) {
	            resp.sendRedirect("login?message=Registration successful! Please login.");
	        } else {
	            resp.sendRedirect("register?error=Registration failed. Please try again.");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        resp.sendRedirect("register?error=An unexpected error occurred. Please try again.");
	    }
	}

}
