package com.aurionpro.servlet;

import java.io.IOException;
import java.util.HashMap;

import com.aurionpro.util.DBUtil;
import com.aurionpro.util.HtmlLoader;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        String errorMessage = "";

        if (session != null && session.getAttribute("loginError") != null) {
            errorMessage = (String) session.getAttribute("loginError");
            session.removeAttribute("loginError");
        }

        String html = HtmlLoader.loadTemplate(getServletContext(), "login.html");
        html = html.replace("${errorMessage}", errorMessage.isEmpty() ? "" : escapeHtml(errorMessage));

        resp.setContentType("text/html");
        resp.getWriter().write(html);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String username = req.getParameter("username");
            String password = req.getParameter("password");

            HttpSession session = req.getSession();

            if (!DBUtil.isUsernameExists(username)) {
                session.setAttribute("loginError", "Username does not exist.");
                resp.sendRedirect("login");
                return;
            }

            int userId = DBUtil.validateUser(username, password);

            if (userId != -1) {
                session.setAttribute("userId", userId);
                session.setAttribute("username", username);
                session.setAttribute("qIndex", 1);
                session.setAttribute("answers", new HashMap<Integer, String>());
                session.removeAttribute("loginError");
                resp.sendRedirect("home");
            } else {
                session.setAttribute("loginError", "Incorrect password.");
                resp.sendRedirect("login");
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    private String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#x27;");
    }
}
