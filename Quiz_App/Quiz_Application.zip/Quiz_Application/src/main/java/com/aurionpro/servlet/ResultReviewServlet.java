package com.aurionpro.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import com.aurionpro.model.Question;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/result-review")
public class ResultReviewServlet extends HttpServlet {
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("username") == null) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        List<Question> reviewQuestions = (List<Question>) s.getAttribute("reviewQuestions");
        Map<Integer, String> reviewAnswers = (Map<Integer, String>) s.getAttribute("reviewAnswers");

        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        StringBuilder json = new StringBuilder();
        json.append("{\"questions\": [");

        if (reviewQuestions != null) {
            for (int i = 0; i < reviewQuestions.size(); i++) {
                Question q = reviewQuestions.get(i);
                String userAns = reviewAnswers != null && reviewAnswers.get(q.getId()) != null ? 
                                 reviewAnswers.get(q.getId()) : "Not Attempted";

                // JSON me option text bhi bhej rahe hain
                json.append("{")
                    .append("\"id\":").append(q.getId()).append(",")
                    .append("\"questionText\":\"").append(q.getQuestionText().replace("\"","\\\"")).append("\",")
                    .append("\"correctOption\":\"").append(q.getCorrectOption().replace("\"","\\\"")).append("\",")
                    .append("\"optionA\":\"").append(q.getOptionA().replace("\"","\\\"")).append("\",")
                    .append("\"optionB\":\"").append(q.getOptionB().replace("\"","\\\"")).append("\",")
                    .append("\"optionC\":\"").append(q.getOptionC().replace("\"","\\\"")).append("\",")
                    .append("\"optionD\":\"").append(q.getOptionD().replace("\"","\\\"")).append("\",")
                    .append("\"userAnswer\":\"").append(userAns.replace("\"","\\\"")).append("\"")
                    .append("}");
                if (i < reviewQuestions.size() - 1) json.append(",");
            }
        }

        json.append("],");
        json.append("\"answers\": {");
        if (reviewAnswers != null) {
            int count = 0;
            for (Map.Entry<Integer, String> e : reviewAnswers.entrySet()) {
                json.append("\"").append(e.getKey()).append("\":\"").append(e.getValue()).append("\"");
                if (count < reviewAnswers.size() - 1) json.append(",");
                count++;
            }
        }
        json.append("}}");

        out.print(json.toString());
        out.flush();
    }
}
