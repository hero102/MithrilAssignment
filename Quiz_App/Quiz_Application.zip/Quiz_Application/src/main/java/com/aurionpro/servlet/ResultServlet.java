package com.aurionpro.servlet;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import com.aurionpro.model.Question;
import com.aurionpro.util.DBUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("username") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        String username = (String) s.getAttribute("username");
        Map<Integer,String> answers = (Map<Integer,String>) s.getAttribute("answers");
        List<Question> questions;

        try {
            questions = DBUtil.getAllQuestions();
            int score = 0;

            for (Question q : questions) {
                String given = answers != null ? answers.get(q.getId()) : null;
                String correct = q.getCorrectOption();
                if (given != null && correct != null &&
                        (given.trim().equalsIgnoreCase(correct.trim()) ||
                        given.trim().substring(0,1).equalsIgnoreCase(correct.trim().substring(0,1)))) {
                    score++;
                }
            }

            // Total attempts
            Integer totalAttempts = (Integer) s.getAttribute("totalAttempts");
            totalAttempts = (totalAttempts != null) ? totalAttempts + 1 : 1;
            s.setAttribute("totalAttempts", totalAttempts);

            // Highest score
            Integer highestScore = (Integer) s.getAttribute("highestScore");
            highestScore = (highestScore != null) ? Math.max(highestScore, score) : score;
            s.setAttribute("highestScore", highestScore);

            // Store question review data in session
            s.setAttribute("reviewQuestions", questions);
            s.setAttribute("reviewAnswers", answers);

            // Clear current answers
            s.removeAttribute("answers");
            s.removeAttribute("qIndex");

            // Redirect to result page with parameters
            String redirectUrl = String.format(
                    "result.html?username=%s&score=%d&total=%d&totalAttempts=%d&highestScore=%d",
                    URLEncoder.encode(username,"UTF-8"), score, questions.size(), totalAttempts, highestScore
            );
            resp.sendRedirect(redirectUrl);

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
