package com.aurionpro.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import jakarta.servlet.ServletContext;

public class HtmlLoader {

    public static String loadTemplate(String fileName) throws IOException {
      
        InputStream is = HtmlLoader.class.getClassLoader().getResourceAsStream(fileName);
        if (is == null) {
            throw new FileNotFoundException("Template not found in classpath: " + fileName);
        }
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }

    // नया method: webapp folder से load करने के लिए
    public static String loadTemplate(ServletContext context, String fileName) throws IOException {
        InputStream is = context.getResourceAsStream("/" + fileName);
        if (is == null) {
            throw new FileNotFoundException("Template not found in webapp: " + fileName);
        }
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }
}
