package com.aurionpro.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aurionpro.model.Question;
import com.aurionpro.util.DBUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/answer")
public class AnswerServlet extends HttpServlet {
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession s = req.getSession(false);
		if (s == null || s.getAttribute("username") == null) {
			resp.sendRedirect("login.html");
			return;
		}

		Integer qIndexObj = (Integer) s.getAttribute("qIndex");
		int qIndex = (qIndexObj != null) ? qIndexObj : 1;

		List<Question> questions;
		try {
			questions = DBUtil.getAllQuestions();

			String option = req.getParameter("option");
			int qId = Integer.parseInt(req.getParameter("qId"));

			Map<Integer, String> answers = (Map<Integer, String>) s.getAttribute("answers");
			if (answers == null)
				answers = new HashMap<>();
			answers.put(qId, option);
			s.setAttribute("answers", answers);

			if (qIndex >= questions.size()) {
				resp.sendRedirect("result");
			} else {
				s.setAttribute("qIndex", qIndex + 1);
				resp.sendRedirect("question");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
