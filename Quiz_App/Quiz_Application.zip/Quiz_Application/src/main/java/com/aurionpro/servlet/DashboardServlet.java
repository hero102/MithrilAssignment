package com.aurionpro.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.aurionpro.util.DBUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/dashboardData")
public class DashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        String username = (String) session.getAttribute("username");
        int highestScore = 0;
        ArrayList<HashMap<String, Object>> attempts = new ArrayList<>();

        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT score, attempt_time FROM quiz_attempts WHERE user_id=? ORDER BY attempt_time DESC");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int score = rs.getInt("score");
                String time = rs.getTimestamp("attempt_time").toString();
                highestScore = Math.max(highestScore, score);

                HashMap<String, Object> attempt = new HashMap<>();
                attempt.put("score", score);
                attempt.put("time", time);
                attempts.add(attempt);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Send JSON manually (no Gson)
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"username\":\"").append(username).append("\",");
        sb.append("\"highestScore\":").append(highestScore).append(",");
        sb.append("\"attempts\":[");
        for (int i = 0; i < attempts.size(); i++) {
            HashMap<String, Object> a = attempts.get(i);
            sb.append("{\"score\":").append(a.get("score"))
              .append(",\"time\":\"").append(a.get("time")).append("\"}");
            if (i != attempts.size() - 1) sb.append(",");
        }
        sb.append("]}");
        out.write(sb.toString());
    }
}
