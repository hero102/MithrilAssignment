package com.aurionpro.util;

import java.io.PrintWriter;

import jakarta.servlet.http.HttpSession;

public class HtmlUtil {
    public static void printHeader(PrintWriter out, String title, HttpSession session) {
        out.println("<!doctype html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='utf-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        out.println("<title>" + title + " - QuizApp</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<link href='" + getContextPath(session) + "/assets/css/styles.css' rel='stylesheet'>");
        out.println("</head>");
        out.println("<body>");
        out.println("<nav class='navbar navbar-expand-lg navbar-dark bg-primary mb-4'>");
        out.println("<div class='container'>");
        out.println("<a class='navbar-brand' href='" + getContextPath(session) + "/question'>QuizApp</a>");
        out.println("<div class='collapse navbar-collapse'>");
        out.println("<ul class='navbar-nav ms-auto'>");
        if (session != null && session.getAttribute("username") != null) {
            out.println("<li class='nav-item'><span class='nav-link'>Hello, " + session.getAttribute("username") + "</span></li>");
            out.println("<li class='nav-item'><a class='nav-link' href='" + getContextPath(session) + "/logout'>Logout</a></li>");
        } else {
            out.println("<li class='nav-item'><a class='nav-link' href='" + getContextPath(session) + "/login'>Login</a></li>");
            out.println("<li class='nav-item'><a class='nav-link' href='" + getContextPath(session) + "/register'>Register</a></li>");
        }
        out.println("</ul></div></div></nav>");
        out.println("<div class='container'>");
    }

    public static void printFooter(PrintWriter out) {
        out.println("</div>"); // container
        out.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>");
        out.println("</body></html>");
    }

    private static String getContextPath(HttpSession s) {
        if (s == null) return "";
        Object ctx = s.getAttribute("contextPath");
        // we will set contextPath attribute later (or use empty)
        return "";
    }
}

