package com.aurionpro.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aurionpro.model.Question;
import com.aurionpro.util.DBUtil;
import com.aurionpro.util.HtmlLoader;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/question")
public class QuestionServlet extends HttpServlet {

    @SuppressWarnings("unchecked")
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("username") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        String retake = req.getParameter("retake");
        if ("true".equalsIgnoreCase(retake)) {
            s.setAttribute("qIndex", 1);
            s.setAttribute("answers", new HashMap<Integer, String>());
        }

        Integer qIndexObj = (Integer) s.getAttribute("qIndex");
        if (qIndexObj == null) qIndexObj = 1;
        int qIndex = qIndexObj;

        try {
            List<Question> questions = DBUtil.getAllQuestions();
            if (questions.isEmpty()) {
                resp.getWriter().write("<h2>No questions found in database</h2>");
                return;
            }

            if (qIndex > questions.size()) {
                resp.sendRedirect("result");
                return;
            }

            Question q = questions.get(qIndex - 1);

            Map<Integer, String> answers = (Map<Integer, String>) s.getAttribute("answers");
            if (answers == null) {
                answers = new HashMap<>();
                s.setAttribute("answers", answers);
            }

            String selectedOption = answers.getOrDefault(q.getId(), "");

            String html = HtmlLoader.loadTemplate(getServletContext(), "question.html");
            html = html.replace("${qIndex}", String.valueOf(qIndex))
                    .replace("${total}", String.valueOf(questions.size()))
                    .replace("${qText}", q.getQuestionText())
                    .replace("${optA}", q.getOptionA())
                    .replace("${optB}", q.getOptionB())
                    .replace("${optC}", q.getOptionC())
                    .replace("${optD}", q.getOptionD())
                    .replace("${checkedA}", selectedOption.equals("A") ? "checked" : "")
                    .replace("${checkedB}", selectedOption.equals("B") ? "checked" : "")
                    .replace("${checkedC}", selectedOption.equals("C") ? "checked" : "")
                    .replace("${checkedD}", selectedOption.equals("D") ? "checked" : "")
                    .replace("${disablePrev}", qIndex == 1 ? "disabled" : "")
                    .replace("${nextLabel}", qIndex == questions.size() ? "Submit Quiz" : "Next")
                    .replace("${progress}", String.valueOf((int)((qIndex * 100.0)/questions.size())));

            resp.setContentType("text/html");
            resp.getWriter().write(html);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("username") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        try {
            String username = (String) s.getAttribute("username");
            int userId = (int) s.getAttribute("userId");

            int qIndex = Integer.parseInt(req.getParameter("qIndex"));
            String selected = req.getParameter("option");

            Map<Integer, String> answers = (Map<Integer, String>) s.getAttribute("answers");
            if (answers == null) answers = new HashMap<>();

            List<Question> questions = DBUtil.getAllQuestions();
            Question q = questions.get(qIndex - 1);
            answers.put(q.getId(), selected);
            s.setAttribute("answers", answers);

            if (qIndex >= questions.size()) {
                // Calculate score
                int score = 0;
                for (Question ques : questions) {
                    String ans = answers.get(ques.getId());
                    if (ques.getCorrectOption().equals(ans)) score++;
                }

                // Save attempt
                DBUtil.saveAttempt(userId, score);

                resp.sendRedirect("result");
            } else {
                s.setAttribute("qIndex", qIndex + 1);
                resp.sendRedirect("question");
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("Error processing quiz: " + e.getMessage());
        }
    }
}
