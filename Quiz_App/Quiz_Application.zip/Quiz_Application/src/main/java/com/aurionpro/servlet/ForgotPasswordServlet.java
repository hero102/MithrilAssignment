package com.aurionpro.servlet;

import java.io.IOException;

import com.aurionpro.util.DBUtil;
import com.aurionpro.util.HtmlLoader;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/forgot-password")
public class ForgotPasswordServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Show form for username & email input
        String html = HtmlLoader.loadTemplate(getServletContext(), "forgot_password.html");
        html = html.replace("${errorMessage}", "");
        resp.setContentType("text/html");
        resp.getWriter().write(html);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String email = req.getParameter("email");

        if (username == null || username.trim().isEmpty() || email == null || email.trim().isEmpty()) {
            resp.sendRedirect("forgot-password?error=Please enter both username and email.");
            return;
        }

        try {
            boolean validUser = DBUtil.isUsernameEmailMatch(username, email);
            if (!validUser) {
                resp.sendRedirect("forgot-password?error=Username and email do not match.");
                return;
            }

            // Save username in session to allow password reset
            req.getSession().setAttribute("resetUsername", username);
            resp.sendRedirect("reset-password");
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("forgot-password?error=Something went wrong.");
        }
    }
}

