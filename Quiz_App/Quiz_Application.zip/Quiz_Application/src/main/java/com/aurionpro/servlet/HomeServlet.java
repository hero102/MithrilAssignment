package com.aurionpro.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.aurionpro.util.HtmlLoader;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login");
            return;
        }

        String username = (String) session.getAttribute("username");
        String html = HtmlLoader.loadTemplate(getServletContext(), "home.html");

        html = html.replace("${username}", username);

        resp.setContentType("text/html");
        resp.getWriter().write(html);
    }
}
