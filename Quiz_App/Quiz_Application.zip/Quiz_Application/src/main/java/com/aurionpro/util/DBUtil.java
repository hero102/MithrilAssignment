package com.aurionpro.util;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.aurionpro.model.Question;

public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/quiz_app";
    private static final String USER = "root";
    private static final String PASS = "Hero@123";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
    public static void saveAttempt(int userId, int score) throws Exception {
        String sql = "INSERT INTO quiz_attempts (user_id, score, attempt_time) VALUES (?, ?, NOW())";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, score);
            ps.executeUpdate();
        }
    }

    // Password hashing utility
    public static String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = md.digest(password.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : hashedBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // Register new user
    public static boolean registerUser(String username, String password, String email) throws Exception {
        String hashedPass = hashPassword(password);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)"
            );
            ps.setString(1, username);
            ps.setString(2, hashedPass);
            ps.setString(3, email);
            return ps.executeUpdate() > 0;
        }
    }

    // Validate user login; returns user id or -1 if invalid
    public static int validateUser(String username, String password) throws Exception {
        String hashedPass = hashPassword(password);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT id FROM users WHERE username=? AND password_hash=?"
            );
            ps.setString(1, username);
            ps.setString(2, hashedPass);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
            return -1;
        }
    }

    // Check if username exists
    public static boolean isUsernameExists(String username) throws Exception {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("SELECT id FROM users WHERE username=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }

    // Check if email exists
    public static boolean isEmailExists(String email) throws Exception {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("SELECT id FROM users WHERE email=?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }

    // Fetch all quiz questions
    public static List<Question> getAllQuestions() throws Exception {
        List<Question> list = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM questions ORDER BY id");
            while (rs.next()) {
                list.add(new Question(
                    rs.getInt("id"),
                    rs.getString("question_text"),
                    rs.getString("option_a"),
                    rs.getString("option_b"),
                    rs.getString("option_c"),
                    rs.getString("option_d"),
                    rs.getString("correct_option")
                ));
            }
        }
        return list;
    }
    
    public static String createPasswordResetToken(String email) throws Exception {
        String token = UUID.randomUUID().toString(); // Random unique token banaya

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            // Token aur expiry time (1 ghanta baad expire hoga) DB me update karo
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE users SET reset_token = ?, reset_token_expiry = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?"
            );
            ps.setString(1, token);
            ps.setString(2, email);
            ps.executeUpdate();
        }

        return token; // Token wapas bhejo taaki reset link me use kar sake
    }
    public static boolean isValidUserEmail(String username, String email) throws Exception {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("SELECT id FROM users WHERE username=? AND email=?");
            ps.setString(1, username);
            ps.setString(2, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }

    public static void updatePasswordByUsername(String username, String newPassword) throws Exception {
        String hashedPass = hashPassword(newPassword);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("UPDATE users SET password_hash=? WHERE username=?");
            ps.setString(1, hashedPass);
            ps.setString(2, username);
            ps.executeUpdate();
        }
    }

    public static boolean isUsernameEmailMatch(String username, String email) throws Exception {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement ps = conn.prepareStatement("SELECT id FROM users WHERE username=? AND email=?");
            ps.setString(1, username);
            ps.setString(2, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }



    // Save quiz result for user
    public static void saveResult(int userId, int score, int totalQuestions) throws Exception {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            PreparedStatement checkUser = conn.prepareStatement("SELECT COUNT(*) FROM users WHERE id=?");
            checkUser.setInt(1, userId);
            ResultSet rs = checkUser.executeQuery();
            rs.next();
            if (rs.getInt(1) == 0) {
                throw new IllegalArgumentException("User ID " + userId + " does not exist.");
            }

            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO results (user_id, score, total_questions) VALUES (?, ?, ?)"
            );
            ps.setInt(1, userId);
            ps.setInt(2, score);
            ps.setInt(3, totalQuestions);
            ps.executeUpdate();
        }
    }
}
