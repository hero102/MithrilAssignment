package com.aurionpro.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/prev")
public class PrevQuestionServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("username") == null) {
            resp.sendRedirect("login.html");
            return;
        }

        int qIndex = (int) s.getAttribute("qIndex");
        if (qIndex > 1) s.setAttribute("qIndex", qIndex - 1);

        resp.sendRedirect("question");
    }
}


