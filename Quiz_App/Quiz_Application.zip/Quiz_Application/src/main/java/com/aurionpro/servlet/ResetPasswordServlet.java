package com.aurionpro.servlet;

import java.io.IOException;

import com.aurionpro.util.DBUtil;
import com.aurionpro.util.HtmlLoader;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/reset-password")
public class ResetPasswordServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Check if username present in session, else redirect to forgot-password
        String username = (String) req.getSession().getAttribute("resetUsername");
        if (username == null) {
            resp.sendRedirect("forgot-password");
            return;
        }

        String html = HtmlLoader.loadTemplate(getServletContext(), "reset_password.html");
        html = html.replace("${errorMessage}", "");
        html = html.replace("${successMessage}", "");
        resp.setContentType("text/html");
        resp.getWriter().write(html);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = (String) req.getSession().getAttribute("resetUsername");
        if (username == null) {
            resp.sendRedirect("forgot-password");
            return;
        }

        String newPassword = req.getParameter("newPassword");
        String confirmPassword = req.getParameter("confirmPassword");

        if (newPassword == null || confirmPassword == null || !newPassword.equals(confirmPassword)) {
            String html = HtmlLoader.loadTemplate(getServletContext(), "reset_password.html");
            html = html.replace("${errorMessage}", "Passwords do not match.");
            html = html.replace("${successMessage}", "");
            resp.setContentType("text/html");
            resp.getWriter().write(html);
            return;
        }

        try {
            // Update password in DB
            DBUtil.updatePasswordByUsername(username, newPassword);

            // Remove session attribute to prevent reuse
            req.getSession().removeAttribute("resetUsername");

            // Show success message or redirect to login page with message
            resp.sendRedirect("login?message=Password updated successfully. Please login.");
        } catch (Exception e) {
            e.printStackTrace();
            String html = HtmlLoader.loadTemplate(getServletContext(), "reset_password.html");
            html = html.replace("${errorMessage}", "Something went wrong. Please try again.");
            html = html.replace("${successMessage}", "");
            resp.setContentType("text/html");
            resp.getWriter().write(html);
        }
    }
}
